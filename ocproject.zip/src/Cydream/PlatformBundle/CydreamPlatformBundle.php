<?php

namespace Cydream\PlatformBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CydreamPlatformBundle extends Bundle
{
}
